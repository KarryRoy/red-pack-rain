var IS_DEBUG = false,
    IS_ONLINE = false;

switch(window.location.hostname){
    case '127.0.0.1':
    case 'topic.zhugejinfu.com':
    case 'localhost':
        IS_ONLINE = false;
        IS_DEBUG = true;
        break;
    case 'cg.zhugelicai.com':
    case 'm.zhugelicai.com':
    case 'm.zhugejinfu.com':
        IS_ONLINE = true;
        IS_DEBUG = false;
        break;
};

var CONFIG = {
    isJava : true,
    isWeChat : !!navigator.userAgent.match(/micromessenger/i),
    isApp : !!navigator.userAgent.match(/zhugeapp/i),
    download : "http://a.app.qq.com/o/simple.jsp?pkgname=com.zglc.financing",
    javaURL : "", 
    phpURL : "",
    pageURL : "",
    topicName : "",
    tokenName : "topicuser_token"
}

CONFIG.javaURL = IS_ONLINE ? "https://api.zhugelicai.com/act/api/" : "http://apitest.zhugejinfu.com/act/api/";
CONFIG.phpURL = (IS_DEBUG ? "http://cgtest.zhugelicai.com" : window.location.origin);
CONFIG.pageURL = (!IS_ONLINE ? "http://cgtest.zhugelicai.com" : "https://m.zhugelicai.com");

var METHOD = {
    ajax : function(url, jsonParam, obj) {

        var defer = Defer(),
            obj = obj || {}, // ajax 其他参数
            cacheResult, // 已缓存结果
            ajaxJquery,
            option = {};
            
        option.url = (!obj.isPhp ? CONFIG.javaURL : CONFIG.phpURL) + url;
        option.type = obj.type || "get";
        jsonParam = jsonParam || {};
        if (IS_DEBUG) {
            jsonParam._dev = 11547;
        }
        
        var opt = {
            url: option.url,
            type: option.type,
            data: jsonParam,
            dataType: "json",
            success: function(json) {
                if (json) {
                    if (!obj.isPhp) {
                        defer.resolve(json);
                    } else {
                        if (json.code == 0) {
                            defer.resolve(json);
                        } else {
                            defer.reject(json);
                        }
                    }
                } else {
                    defer.reject({});
                }
            },
            error: function(xhr, error) {
                defer.reject({});
            }
        };

        if (!obj.isPhp) {
            if (Auth.token && !obj.noToken) {
                opt.headers = {'Authorization':'Bearer '+ Auth.token };
            }
            ajaxJquery = $.ajax(opt);
        } else {
            if(!Bridge.flag) {
                ajaxJquery = $.ajax(opt);
            } else {
                Bridge.getUser(function(bd) {
                    opt.headers = {
                        "x-user-token": bd.token,
                        "x-user-platform": bd.platform
                    };
                    ajaxJquery = $.ajax(opt);
                });
            }
        }
        defer.abort = function() {
            ajaxJquery && ajaxJquery.abort();
            defer.reject({});
        };


        return defer;
    },
    goPage : function(id){
        var zglcurl = "";
        if (Bridge.flag) {
            if (!id) {
                Bridge.gotoPage("invest");
            } else {
                Bridge.gotoPage("invest/bao?id=" + id);
            }
        } else if (CONFIG.isWeChat || !IS_ONLINE){
            if (!id) {
                window.location.href = CONFIG.pageURL + "/?hash=invest#invest";
            } else {
                window.location.href = CONFIG.pageURL + "/?hash=invest%2Fbao%3Fid%3D"+ id +"#invest/bao?id="+ id;
            }
        } else {
            window.location.href = CONFIG.download;
        }
    },
    goLogin : function(){
        if (Bridge.flag) {
            Bridge.gotoPage("login");
        } else if (CONFIG.isWeChat || !IS_ONLINE){
            window.location.href = CONFIG.pageURL + "/?hash=register#register";
        } else {
            window.location.href = CONFIG.download;
        }
    },
    judgeEndTime : function(now, end) {
        now = typeof now === 'number' ? now : now.getTime();
        end = (typeof end === 'number' ? end : end.getTime()) + 86400000;

        if (now > end) { 
            $('body').append("<div class='m_end' style='position: absolute;top: 0;left: 0;right: 0;height: 1.06667rem;line-height: 1.06667rem;background: #fff;color: #FF4141;padding-left: .26667rem;font-size: .4rem;'>活动已结束！</div>"); 
            return true;
        }  else {
            return false;
        }
    },
    alert : function(mess, time) {
        var defer = Defer();
        var $tool = $("#J__m_tooltips");
        if($tool.hasClass('on')) return;
        if ($tool.length) {
            $tool.find(".tooltip-text").html(mess);
        } else {
            $tool = $('<div id="J__m_tooltips" class="m_tooltips none"/>');
            $('<div class="tooltip-text tooltip-content"/>').html(mess).appendTo($tool);
            $tool.appendTo('body');
        }

        $tool.removeClass("none");
        $tool.get(0).offsetHeight;
        $tool.addClass("on");

        time = time || 2000;
        setTimeout(function() {
            $tool.removeClass("on");
            $tool.addClass("none");
            defer.resolve();
        }, time);
        return defer;
    },
    loading : {
        $loaiing: $("#J__m_loading"),
        show: function(mess, type) {
            if (!this.$loaiing.length) return;
            mess = (mess ? mess : '加载中');
            this.$loaiing.find(".J__loadingmess").html(mess);
            // 全屏的
            if (type === 2) {
                this.$loaiing.addClass("full");
            }
            this.$loaiing.addClass("on");
        },
        hide: function() {
            this.$loaiing.removeClass("on full");
        }
    },
    goHui : function(params){
        // params._hf = 1;
        var tempform = document.createElement("form");
        var huiUrl = [
            "https://lab.chinapnr.com/muser/publicRequests",    // 生产
            "http://mertest.chinapnr.com/muser/publicRequests"  //测试
        ];
        tempform.action = huiUrl[params["_hf"] || 0];
        tempform.method = "post";
        tempform.style.display = "none";

        var p = params || {},
            opt;

        for (var x in p) {
            if (p.hasOwnProperty(x) && x !== "_hf") {
                opt = document.createElement("input");
                opt.name = x;
                opt.setAttribute("value", p[x]);
                tempform.appendChild(opt);
            }
        }
        var opt = document.createElement("input");
        opt.type = "submit";
        tempform.appendChild(opt);
        document.body.appendChild(tempform);
        tempform.submit();
    }
};

// java登录
var Auth = (function(){
    
    var code = getQueryParms("code");
    var tn = CONFIG.tokenName;
    var token = window.localStorage.getItem(tn);
    var callbackfn = [];
    var me;

    function init(){
        if (!token) {
            if (!code ) {
                getCode();
            } else {
                $.ajax({
                    url : CONFIG.phpURL + "/m/uniform/token",
                    data : { code : code },
                    dataType:'json',
                    success : function(json) {
                        if(json.data && json.code == 0){
                            // -1 未注册  0 旧系统 1 正常
                            if (json.data.userType == 1) {
                                window.localStorage.setItem(tn, json.data.token);
                            }
                            callbackfn.forEach(function(v){
                                token = json.data.token;
                                me.token = token;
                                v && v(json.data);
                            });
                        } else {
                            getCode();
                        }
                    },
                    fail : function(){
                        getCode();
                    }
                });
            }
        } else {
            callbackfn.forEach(function(v){
                v && v({token:token,userType:1});
            });
        }
    }
    function remove(){
        window.localStorage.removeItem(tn);
    }
    function getCode(){
        window.localStorage.removeItem(tn);
        var url = CONFIG.phpURL + "/m/uniform/auth?fromId=newyear&login=0&redirectUrl=" + encodeURIComponent(window.location.origin + window.location.pathname + window.location.hash);
        window.location.replace(url);
    }
    function getQueryParms(name) {
        var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
        var r = window.location.search.substr(1).match(reg);
        if (r != null) {
            return unescape(r[2]);
        }
        return null;
    }
    me = {
        init : init,
        token : token,
        remove : remove,
        getCode : getCode,
        ready : function(fn){
            callbackfn.push(fn);
        },
        getQueryParms : getQueryParms
    }
    return me;

})();

// 微信
var wxReady = (function(){
    var url = encodeURIComponent(location.href.split('#')[0]);
    var apiList = ["onMenuShareTimeline", "onMenuShareAppMessage"];

    var getajax = function(fn){
        var url = encodeURIComponent(location.href.split('#')[0]);
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange=function(){
            if(xhr.readyState === 4){
                if(xhr.status === 200){
                    var text = xhr.responseText;
                    fn(JSON.parse(text));
                }else{}
            }
        }
        xhr.open('GET', CONFIG.phpURL + '/api/wx/jsconfig?url='+url, true);
        xhr.send(null);
    }

    return {
        init : function(){
            if (!Bridge.flag) {
                getajax(function(json){
                    var wxconfig = {
                          debug: false,
                          appId: json.data.appId,
                          timestamp: json.data.timestamp,
                          nonceStr: json.data.nonceStr,
                          signature: json.data.signature,
                          jsApiList : apiList
                    };
                    wx.config(wxconfig);
                });
            }
        },
        share : function(obj){
            obj = obj || {};
            obj.imgUrl = obj.imgUrl || ("http://img.zhugejinfu.com/app/share/shanzi2.jpg");
            obj.link = obj.link || window.location.href;
            var fncc;
            if (!Bridge.flag) {
                fncc = function(){
                    // 分享到朋友
                    wx.onMenuShareAppMessage({
                        title: obj.title, desc: obj.desc, link: obj.link, imgUrl: obj.imgUrl, type: '', dataUrl: '',
                        success: function() {
                            obj.success && obj.success(); 
                            METHOD.ajax("/api/wx/share", {title:obj.title, url:obj.link, topic:CONFIG.topicName, type:1}, { type : "post", isPhp:true } );
                        },
                        cancel: function() {obj.fail && obj.fail(); }
                    });
                    // 分享到朋友圈
                    wx.onMenuShareTimeline({
                        title: obj.title, link: obj.link, imgUrl: obj.imgUrl,
                        success: function () {
                            obj.success && obj.success(); 
                            METHOD.ajax("/api/wx/share", {title:obj.title, url:obj.link, topic:CONFIG.topicName, type:3}, { type : "post", isPhp:true } );
                        },
                        cancel: function () {obj.fail && obj.fail(); }
                    });
                };
                wx.ready(fncc);
            } else {
                obj.open = 1;
                Bridge.call("pageShareState", obj, function(data){
                    data = JSON.parse(data) || null;
                    if (data.result == 1) {
                        METHOD.ajax("/api/wx/share", {title:obj.title, url:obj.link, topic:CONFIG.topicName, type:1}, { type : "post", isPhp:true } );
                    }
                });
            }
        }
    }
})();

// 行为记录
var actionSend = function(){
    var xhr = new XMLHttpRequest();
    var type = 1, 
    userobj = {
        loadTime : 0,
        allTime : 0,
        ua : navigator.userAgent,
        referrer : document.referrer,
        pages : {}
    };

    var url = CONFIG.phpURL;

    var data = encodeURIComponent(JSON.stringify(userobj));

    if (Bridge.flag) {
        if (navigator.userAgent.match(/Android/i)) {
            type = 4;
        } else {
            type = 3;
        }
        Bridge.getUser(function(bd){
            xhr.open("post", url + "/api/common/visit/record?type=" + type + "&source=" + CONFIG.topicName, false);
            xhr.setRequestHeader("X-User-Platform", bd.platform);
            xhr.setRequestHeader("X-User-Token", bd.token);
            xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhr.send("action=" +  data);
        });
    } else {
        xhr.open("post", url + "/api/common/visit/record?type=" + type +"&source=" + CONFIG.topicName, false);
        xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        xhr.send("action=" +  data);
    }
};
